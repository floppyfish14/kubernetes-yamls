<?PHP

phpinfo();

?>
