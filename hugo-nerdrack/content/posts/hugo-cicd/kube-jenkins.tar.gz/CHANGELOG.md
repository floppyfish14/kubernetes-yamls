CHANGELOG
=========

2.99
-----
*  `/bin/tini` has been relocated to `/sbin/tini`, location defined by alpine
