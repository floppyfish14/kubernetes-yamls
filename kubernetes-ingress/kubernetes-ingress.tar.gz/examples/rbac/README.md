# RBAC

It is possible to run the Ingress controller in a cluster with [RBAC](https://kubernetes.io/docs/admin/authorization/rbac/) enabled. Read the installation instructions [here](../../docs/installation.md).